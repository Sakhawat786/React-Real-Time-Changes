import React from 'react'
function handleChange(){
var fname = document.getElementById("fname").value;
var lname = document.getElementById("lname").value;
var range = document.getElementById("rng").value;
var color = document.getElementById("clr").value;
var imagerange = document.getElementById("imgrng").value;

var details = document.getElementById("details");
const image = document.getElementById("img");
const previewContainer = document.getElementById("imgaePreview");
const previweImage = previewContainer.querySelector(".image-preview__image");


image.addEventListener("change", function(){
    const imagefile = this.files[0];
    if(imagefile){
        const reader = new FileReader();
        previweImage.style.display = "block";
        reader.addEventListener("load",function(){
            console.log(this);
            previweImage.setAttribute("src",this.result);
        });
        reader.readAsDataURL(imagefile);
    }
    else
    {
        previweImage.style.display = null;
        previweImage.setAttribute("src","");
    }
});


details.innerHTML = fname+ " " +lname;
details.style.color = color;
details.style.fontSize = range+"px";
previweImage.style.width = imagerange+"px";
previweImage.style.height = imagerange+"px";
}

function DataForm(){   
let style = {
    borderRadius : "100%",
    display : "block"
}
return (
<div className="container-fluid row">
    <div className=" col-md-6">
    <form className="form col-lg-12">
    <h1 className="text-center text-info m-5">Ok Done...</h1>
    <div className="form-group">
        <label className="text-info">First Name...</label>
    <input onChange={handleChange} className="form-control text-center text-info" type="text" id="fname"/>
    </div>
    <div className="form-group">
        <label className="text-info">Last Name...</label>
    <input onChange={handleChange} className="form-control text-center text-info" type="text" id="lname"/>
    </div>
    
    <div className="form-group">
        <label className="text-info">Color...</label>
    <input onChange={handleChange} className="form-control text-center text-info" type="color" id="clr"/>
    </div>
    
    <div className="form-group">
        <label className="text-info">Font Size...</label>
    <input onChange={handleChange} className="form-control text-center text-info" type="range" id="rng" min="20" max="50"/>
    </div>
    
    <div className="form-group">
        <label className="text-info">Image Size...</label>
    <input onChange={handleChange} className="form-control" type="range" id="imgrng" min="50" max="500"/>
    </div>
    
    <div className="form-group">
        <label className="text-info">Profile Image...</label>
    <input onChange={handleChange} className="form-control-file text-center text-info" type="file" id="img" />
    </div>
    </form>
    </div>
    <div className="col-md-6 text-center">
    <h1 className="text-center text-info m-5">Hi There</h1>
    <p className="text-center text-info">Your Detail Is Below...</p>
    <h1 className="details" id="details"></h1>

    <div className="image-preview w-50 h-50" id="imgaePreview">
        <img alt="" style={style} className="ml-5 image-preview__image"></img>
        </div>
    
    </div>
</div>
);
}
export default DataForm();