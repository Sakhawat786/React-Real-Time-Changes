import React from 'react'
import ReactDOM from 'react-dom' 
import DataForm from './components/Form.js'
import "./css/bootstrap.css"
import "./css/bootstrap.min.css"
import "./css/bootstrap-grid.css"
import "./css/bootstrap-grid.min.css"
import "./css/bootstrap-reboot.css"
import "./css/bootstrap-reboot.min.css"
const element = <h1 class="text-center text-info mt-4">Hello React Project...</h1>

ReactDOM.render(DataForm,document.getElementById('root'));